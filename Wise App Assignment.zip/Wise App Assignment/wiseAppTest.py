import traceback
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
import time

# Initialize the WebDriver (Chrome in this case)
driver = webdriver.Chrome()

def wiseAppTest():
    try:
        driver.maximize_window()
        driver.implicitly_wait(10)  # Set implicit wait time
        driver.get("https://staging-web.wise.live")
        
        # Login Page Actions
        driver.find_element(By.XPATH, "//button[normalize-space()='Continue with Mobile']").click()
        driver.find_element(By.XPATH, "//input[@placeholder='Phone number']").send_keys("1111100000")
        driver.find_element(By.XPATH, "//button[normalize-space()='Get OTP']").click()
        
        otp_blocks = driver.find_elements(By.XPATH, "//input[@autocomplete='one-time-code']")
        otp_code = "0000"  # Replace with actual OTP
        
        # Validate OTP blocks
        if len(otp_blocks) == len(otp_code):
            for i, block in enumerate(otp_blocks):
                block.send_keys(otp_code[i])
        else:
            print(f"Mismatch: Found {len(otp_blocks)} OTP blocks but OTP has {len(otp_code)} digits.")
        
        driver.find_element(By.XPATH, "//button[normalize-space()='Verify']").click()
        
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//*[contains(text(), 'Testing Institute')]"))
        )
        assert "Testing Institute" in driver.page_source, "Login failed"
        
        # Navigate to classroom
        driver.find_element(By.XPATH, "//span[contains(text(), 'Group courses')]").click()
        driver.find_element(By.XPATH, "//a[contains(text(), 'testing')]").click()
        
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//*[contains(text(), 'Classroom for Automated testing')]"))
        )
        assert "Classroom for Automated testing" in driver.page_source, "Navigation failed"
        
        # Open Live Sessions tab
        live_sessions_tab = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//a[contains(text(), 'Live Sessions')]"))
        )
        live_sessions_tab.click()
        
        # Click Schedule Sessions
        schedule_sessions_option = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//span[normalize-space()='Schedule Sessions']"))
        )
        schedule_sessions_option.click()
        
        # Add a session
        add_session_btn = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//span[normalize-space()='Add session']"))
        )
        add_session_btn.click()
        
        # Wait for loader to disappear
        WebDriverWait(driver, 10).until(
            EC.invisibility_of_element_located((By.XPATH, "//div[@class='loader']"))
        )

        # Interact with session time
        sessionTime = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//div[@role='combobox']//input"))
        )
        sessionTime.click()
        sessionTime.clear()
        sessionTime.send_keys("10:00")
        sessionTime.send_keys(Keys.ENTER)
        
        sessionZone = WebDriverWait(driver, 20).until(
            EC.element_to_be_clickable((By.XPATH, "//div[@class='pa-2 d-flex align-center pointer justify-center interval-card']//div"))
        )

        # Check the current text
        currentText = sessionZone.text
        
        if currentText == 'PM':
            print("PM is already selected. No action needed.")
        else:
            sessionZone.click()  # Switch to PM
            for _ in range(5):  # Retry a few times to confirm the change
                currentText = sessionZone.text
                if currentText == 'PM':
                    print("Switched to PM successfully")
                    break
                sessionZone.click()  # Retry clicking if not switched
            else:
                print("Failed to switch to PM")
        
        # Finalize session start if needed (add any missing actions)
        save_btn = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//span[normalize-space()='Create']"))
        )
        save_btn.click()
        sessionName = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "(//div[@class = 'font-weight--600'])[1]"))
            
        )
        
        sessionNameText = sessionName.text
        # Assert that the text is as expected
        assert sessionNameText == "Live session", f"Expected text 'Live session', but got '{sessionNameText}'"
        
        print("Assertion passed: Text matches 'Live session'")
        
        hosted_by_element = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "(//div[@class = 'text--10 greySecondary--text mb-1 text-uppercase'])[1]"))
        )
        
        hosted_by_text = hosted_by_element.text
        # Assert that the text is as expected
        assert hosted_by_text == "HOSTED BY WISE TESTER", f"Expected text 'HOSTED BY WISE TESTER', but got '{hosted_by_text}'"
        
        print("Assertion passed: Text matches 'HOSTED BY Wise Tester'")
        
        created_session = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "(//div[@class = 'text--12 greySecondary--text text-no-wrap'])[1]"))
)

        # Get the text of the element
        session_text = created_session.text

        # Assert that the text contains "Sun, 10:00 pm - 11:00 pm"
        assert "Sun, 10:00 pm - 11:00 pm" in session_text, f"Expected text not found! Found: '{session_text}'"
        
        # Print success message
        print("Assertion passed: Text matches 'Sun, 10:00 pm - 11:00 pm'")
        
        
    except Exception as e:
        print(f"Error occurred: {e}")
        traceback.print_exc()  # Prints the complete traceback to the console for debugging
    finally:
        input("Press Enter to exit...")  # Keeps the browser open for inspection
        driver.quit()

if __name__ == "__main__":
    wiseAppTest()
